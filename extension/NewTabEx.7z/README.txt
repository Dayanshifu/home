https://hao.littleyan.tk/ 
crx为chrome、新edge等chromium内核浏览器的扩展，
zip为除ie、safari等浏览器外通用的扩展程序（chromium和firefox都可）。
使用方法：自行百度